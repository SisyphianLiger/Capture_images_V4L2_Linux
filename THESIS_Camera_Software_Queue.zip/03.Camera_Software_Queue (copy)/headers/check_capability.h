#ifndef CHECK_CAPABILITY_H
#define CHECK_CAPABILITY_H

// Libraries`
#include <linux/videodev2.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <stdio.h>

// Important Structs` 

// Functions
int query_capabilities(int fd);
// Static function for query_capture

#endif  



